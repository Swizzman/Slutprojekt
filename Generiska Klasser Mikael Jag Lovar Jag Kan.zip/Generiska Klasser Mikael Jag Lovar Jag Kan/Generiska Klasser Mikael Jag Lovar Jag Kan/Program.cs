﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generiska_Klasser_Mikael_Jag_Lovar_Jag_Kan
{
    class Program
    {
        static void Main(string[] args)
        {
            //Lite variabler
            string userAnswer;
            string userAnswer2;
            bool wantToAdd = true;
            int queueNumber;
            //En lista är som en dynamisk array. Det betyder att den kan ändra storlek om så behövs.
            List<string> ultimateList = new List<string>();
            //En Queue liknar en lista men kan endast addera vid början och subtrahera från slutet. Användbart vid exempelvis produktionsköer i strategispel
            Queue<int> manyNumbers = new Queue<int>();
            //En dictionary är som en lista fast istället för att indexet är ett nummer så kan det vara vad som helst som en string eller float.
            Dictionary<string, string> coolestDictionary = new Dictionary<string, string>();
            //Denna loop lägger till saker till listan sålänge som användaren vill
            while (wantToAdd)
            {
                Console.WriteLine("Add something to the list!");

                userAnswer = Console.ReadLine();
                while (userAnswer.Length < 1)
                {
                    Console.WriteLine("Please Don't press just Enter!");
                    userAnswer = Console.ReadLine();
                }
                ultimateList.Add(userAnswer);
                Console.WriteLine("Do you want to add something more? y/n");
                userAnswer = Console.ReadLine();

                //Om spelaren vill fortsätta får hen skriva något annat än 
                if (userAnswer.Trim().ToLower() == "n")
                {
                    wantToAdd = false;
                }
                else if (userAnswer.Trim().ToLower() == "y")
                {
                    Console.WriteLine("Good Luck!");
                }
                else
                {
                    Console.WriteLine("You did not give a correct answer. Assuming yes.");
                }
            }
            Console.Clear();
            wantToAdd = true;
            while (wantToAdd)
            {
                Console.WriteLine("Add an integer number to the Queue!");
                userAnswer = Console.ReadLine();
                while (userAnswer.Length < 1)
                {
                    Console.WriteLine("Please Don't press just Enter!");
                    userAnswer = Console.ReadLine();
                }
                //Kontrollerar om det inskrivna numret faktiskt är en int med hjälp av en TryParse
                if (int.TryParse(userAnswer, out queueNumber))
                {
                    manyNumbers.Enqueue(queueNumber);
                    Console.WriteLine("Do you want to add something more? y/n");
                    userAnswer = Console.ReadLine();
                    if (userAnswer.Trim().ToLower() != "n")
                    {
                        Console.WriteLine("That was not a correct answer. Do you want to add something more? y/n");
                    }
                    else if (userAnswer.Trim().ToLower() == "y")
                    {
                        Console.WriteLine("Good Luck!");
                    }
                    else
                    {
                        wantToAdd = false;
                    }
                }
                else
                {
                    Console.WriteLine("That was not an integer number!");
                }


            }
            wantToAdd = true;
            //Denna loop hanterar Dictionaryn
            while (wantToAdd)
            {
                //Hämtar in två svar från användaren och låter användaren göra sin egna ordbok
                Console.WriteLine("Add something to the Dictionary");
                userAnswer = Console.ReadLine();
                while (userAnswer.Length < 1)
                {
                    Console.WriteLine("Please Don't press just Enter!");
                    userAnswer = Console.ReadLine();
                }
                Console.WriteLine("How would you describe the word?");
                userAnswer2 = Console.ReadLine();
                while (userAnswer2.Length < 1)
                {
                    Console.WriteLine("Please Don't press just Enter!");
                    userAnswer = Console.ReadLine();
                }
                //Lägger till båda svaren till Dictionaryn
                coolestDictionary.Add(userAnswer, userAnswer2);
                Console.WriteLine("Do you want to add something more? y/n");
                userAnswer = Console.ReadLine();
                //Kollar om användaren inte vill fortsätta. Annars får personen addera ytterliggare ett ord. 
                if (userAnswer.Trim().ToLower() == "n")
                {
                    wantToAdd = false;
                }
                else if (userAnswer.Trim().ToLower() == "y")
                {
                    Console.WriteLine("Great!");
                }
                else
                {
                    Console.WriteLine("You did not give a correct answer. Assuming yes.");
                }
            }
            Console.Clear();
            //Skriver ut alla generiska klasser
            Console.WriteLine("Your List included:");
            for (int i = 0; i < ultimateList.Count; i++)
            {
                Console.WriteLine(ultimateList[i]);
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Your Queue included:");
            while (manyNumbers.Count > 0)
            {
                Console.WriteLine(manyNumbers.Dequeue());
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Your Dictionary included:");

            //Gör om Dictionaryn till en lista och skriver ut den med hjälp av en foreach-loop
            coolestDictionary.ToList().ForEach(x => Console.WriteLine(x.Key + ": " + x.Value));

            Console.ReadLine();

        }
    }
}
